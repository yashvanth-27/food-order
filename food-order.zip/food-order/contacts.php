<html>
    <h1>For more queries please contact below persons</h1>
<table class="tbl-30">
    
    <tr>
        <td>Full Name</td>
        <td>abc</td>
    </tr>
    <tr>
        <td>Phone Numer</td>
        <td>713xxxxxxxx</td>
    </tr>
    <tr>
        <td>Email Id</td>
        <td><a href="abc@gmail.com">abc@gmail.com</a></td>
    </tr>
</table><br><br>
<table class="tbl-30">
    
    <tr>
        <td>Full Name</td>
        <td>abc</td>
    </tr>
    <tr>
        <td>Phone Numer</td>
        <td>914xxxxxx</td>
    </tr>
    <tr>
        <td>Email Id</td>
        <td><a href="abc@gmail.com">abc@gmail.com</a></td>
    </tr>
</table>





</html>